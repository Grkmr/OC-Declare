from .oc_declare import *

__doc__ = oc_declare.__doc__
if hasattr(oc_declare, "__all__"):
    __all__ = oc_declare.__all__